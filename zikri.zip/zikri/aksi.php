<?php

$Nama =$_POST['Nama'];
$Hp =$_POST['Hp'];
echo "<h1><center>Hai" .$Nama."</center></h1><br>";
echo "nomor hp anda" .$Hp;

?>